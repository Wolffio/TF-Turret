                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1013775
Team Fortress 2 Level One Sentry Gun by Scampi is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

The level 1 sentry gun from TF2. This model is incredibly accurate, being created directly from valve's model. The only changes I made to it were to allow for printing and to allow for the joints to move. As of now, the finished model will require a little sanding and glue, but I'll remedy this soon. This model makes an excellent desk toy or display piece, and is sure to end up forcing you to try to explain TF2 to someone! A must-have for Team Fortress fans and Engie mains.  

Don't forget to post a make of it if it turns out really well!

(edit) Now that I've got access to SolidWorks, I'm considering remaking this

# Instructions

It is pretty simple to put together.   

1 Print out all the parts to whatever scale you want. There are some small details and pieces, so try to go large if your printer isn't amazing. The single largest piece is the AmmoDrum, so make sure that fits in the printing area.   

2 Plan the assembly. Find a good picture of a TF2 sentry, and figure out where everything goes. The parts are also named, so that should help.  

3 Assemble the gun. Don't do any gluing until you know that everything is correct. Some parts may need to be filed/sanded to fit into place, especially the moving joints. You can make them as stiff or as loose as you need to. Oh, and the right and left part designation is correct when looking at the gun head-on.  

If you get stuck, I made a mistake, or something isn't right, let me know. Let me know what you think. Thanks, and have fun!